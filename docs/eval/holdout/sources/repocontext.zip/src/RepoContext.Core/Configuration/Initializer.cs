using RepoContext.Core.Scanning;

namespace RepoContext.Core.Configuration;

/// <summary>The outcome of <c>repoctx init</c>.</summary>
public sealed record InitResult
{
    public required bool ConfigCreated { get; init; }

    public required bool ConfigOverwritten { get; init; }

    public required bool GitignoreUpdated { get; init; }

    public required string ConfigPath { get; init; }

    /// <summary>
    /// Per-file outcome for the agent-instruction files (empty when they were
    /// not requested).
    /// </summary>
    public IReadOnlyList<AgentFileResult> AgentFiles { get; init; } = [];

    /// <summary>
    /// Project roots found below the repository root, ordered by path. All of
    /// them are covered by the written configuration; this is what
    /// <c>init</c> reports so a multi-project checkout can be verified at a
    /// glance.
    /// </summary>
    public IReadOnlyList<DetectedProject> Projects { get; init; } = [];

    /// <summary>Number of files the written configuration selects for indexing.</summary>
    public required int ScannedFiles { get; init; }
}

/// <summary>Initializes a repository for RepoContext (spec F1).</summary>
public static class Initializer
{
    /// <summary>
    /// Creates <c>.repoctx/</c>, writes the default <c>repoctx.config.json</c>,
    /// and ensures <c>.gitignore</c> excludes the index directory.
    /// </summary>
    /// <param name="writeAgentInstructions">
    /// When true, also create/update the agent-instruction files
    /// (<c>CLAUDE.md</c>, <c>AGENTS.md</c>) with the RepoContext usage block.
    /// </param>
    /// <exception cref="InvalidOperationException">
    /// Thrown when already initialized and <paramref name="force"/> is false.
    /// </exception>
    public static InitResult Initialize(RepoLayout layout, bool force, bool writeAgentInstructions = false)
    {
        bool alreadyInitialized = File.Exists(layout.ConfigPath);
        if (alreadyInitialized && !force)
        {
            throw new InvalidOperationException(
                $"Already initialized ({RepoContextInfo.ConfigFileName} exists). Use --force to overwrite.");
        }

        Directory.CreateDirectory(layout.IndexDirectory);
        RepoctxConfig config = RepoctxConfig.CreateDefault();
        ConfigStore.Save(layout.ConfigPath, config);

        bool gitignoreUpdated = EnsureGitignore(layout.Root);

        // Reported, not persisted: the scan covers the whole repository, so the
        // detected projects only tell the user what that amounts to here.
        IReadOnlyList<ScannedFile> scanned = new FileScanner(layout.Root, config).Scan();

        var agentFiles = new List<AgentFileResult>();
        if (writeAgentInstructions)
        {
            foreach (string fileName in AgentInstructions.DefaultFileNames)
            {
                agentFiles.Add(AgentInstructions.Ensure(layout.Root, fileName));
            }
        }

        return new InitResult
        {
            ConfigCreated = !alreadyInitialized,
            ConfigOverwritten = alreadyInitialized,
            GitignoreUpdated = gitignoreUpdated,
            ConfigPath = layout.ConfigPath,
            AgentFiles = agentFiles,
            Projects = ProjectDetector.Detect(scanned),
            ScannedFiles = scanned.Count,
        };
    }

    private static bool EnsureGitignore(string root)
    {
        string path = Path.Combine(root, ".gitignore");
        const string entry = ".repoctx/";

        if (!File.Exists(path))
        {
            File.WriteAllText(path, entry + "\n");
            return true;
        }

        string[] lines = File.ReadAllLines(path);
        foreach (string line in lines)
        {
            string trimmed = line.Trim();
            if (trimmed is entry or ".repoctx" or "/.repoctx" or "/.repoctx/")
            {
                return false;
            }
        }

        string existing = File.ReadAllText(path);
        string prefix = existing.Length > 0 && !existing.EndsWith('\n') ? "\n" : string.Empty;
        File.AppendAllText(path, prefix + "\n# RepoContext index (machine-local, sensitive)\n" + entry + "\n");
        return true;
    }
}
