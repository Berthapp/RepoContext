using System.Text;
using System.Text.Json;
using RepoContext.Core;
using RepoContext.Core.Indexing;

namespace RepoContext.Cli.Output;

/// <summary>Renders <c>changed</c> results as text, JSON or Markdown.</summary>
public static class ChangedOutput
{
    public static string Render(ChangedResult result, OutputFormat format) => format switch
    {
        OutputFormat.Json => RenderJson(result),
        OutputFormat.Md => RenderMarkdown(result),
        _ => RenderText(result),
    };

    private static string RenderText(ChangedResult r)
    {
        var sb = new StringBuilder();
        if (!r.Stale)
        {
            sb.Append(
                $"Index is current (content {r.ContentState}, worktree {r.WorktreeState}). No changes.\n");
            AppendUnreadable(sb, r);
            return sb.ToString();
        }

        sb.Append(
            $"Index is stale (content {r.ContentState}, worktree {r.WorktreeState}). "
            + "Run 'repoctx index'.\n");
        sb.Append("Changed:\n");
        foreach (ChangedFile file in r.Changed)
        {
            sb.Append($"  {file.Status,-8}  {file.Path}");
            if (file.Hunks is not null && file.PatchTokens is { } patchTokens && file.FileTokens is { } fileTokens)
            {
                sb.Append($"  (~{patchTokens} patch tokens vs {fileTokens} full read)");
            }

            sb.Append('\n');
            foreach (PatchHunk hunk in file.Hunks ?? [])
            {
                sb.Append($"      @@ -{hunk.OldStart},{hunk.OldLines} +{hunk.NewStart},{hunk.NewLines} @@\n");
                foreach (string line in hunk.Text.Split('\n'))
                {
                    sb.Append("      ").Append(line).Append('\n');
                }
            }
        }

        if (r.Impacted.Count > 0)
        {
            sb.Append("Impacted (link to a change):\n");
            foreach (ImpactedFile file in r.Impacted)
            {
                sb.Append($"  {file.Path}  ({string.Join(", ", file.Reasons)})\n");
            }
        }

        AppendUnreadable(sb, r);
        return sb.ToString();
    }

    private static string RenderMarkdown(ChangedResult r)
    {
        var sb = new StringBuilder();
        sb.Append("# Changed\n\n");
        sb.Append(r.Stale
            ? $"_Index **stale** (content `{r.ContentState}` · worktree `{r.WorktreeState}`) — "
                + "run `repoctx index`._\n\n"
            : $"_Index current (content `{r.ContentState}` · worktree `{r.WorktreeState}`). "
                + "No changes._\n");
        foreach (ChangedFile file in r.Changed)
        {
            sb.Append($"- **{file.Status}** `{file.Path}`");
            if (file.Hunks is not null && file.PatchTokens is { } patchTokens && file.FileTokens is { } fileTokens)
            {
                sb.Append($" — ~{patchTokens} patch tokens vs {fileTokens} full read");
            }

            sb.Append('\n');
            if (file.Hunks is { Count: > 0 } hunks)
            {
                sb.Append("\n```diff\n");
                foreach (PatchHunk hunk in hunks)
                {
                    sb.Append($"@@ -{hunk.OldStart},{hunk.OldLines} +{hunk.NewStart},{hunk.NewLines} @@\n");
                    sb.Append(hunk.Text).Append('\n');
                }

                sb.Append("```\n\n");
            }
        }

        if (r.Impacted.Count > 0)
        {
            sb.Append("\n## Impacted\n\n");
            foreach (ImpactedFile file in r.Impacted)
            {
                sb.Append($"- `{file.Path}` — {string.Join(", ", file.Reasons)}\n");
            }
        }

        if (r.Unreadable.Count > 0)
        {
            sb.Append("\n## Unreadable (not checked)\n\n");
            foreach (string path in r.Unreadable)
            {
                sb.Append("- `").Append(path).Append("`\n");
            }
        }

        if (r.UnreadableIgnoreFiles.Count > 0)
        {
            sb.Append("\n## Ignore rules not applied\n\n");
            foreach (string path in r.UnreadableIgnoreFiles)
            {
                sb.Append("- `").Append(path).Append("` could not be read, so the paths it "
                    + "excludes appear above\n");
            }
        }

        return sb.ToString();
    }

    /// <summary>
    /// Names the files nothing could be said about, and separately the ignore
    /// files whose rules did not apply. Without the first, an unreadable file is
    /// indistinguishable from a verified-current one; without the second, the
    /// files those rules would have excluded appear as unexplained additions.
    /// </summary>
    private static void AppendUnreadable(StringBuilder sb, ChangedResult r)
    {
        if (r.Unreadable.Count > 0)
        {
            sb.Append("Unreadable (not checked):\n");
            foreach (string path in r.Unreadable)
            {
                sb.Append("  ").Append(path).Append('\n');
            }
        }

        if (r.UnreadableIgnoreFiles.Count > 0)
        {
            sb.Append("Ignore rules not applied (unreadable), so the paths they exclude "
                + "are listed above:\n");
            foreach (string path in r.UnreadableIgnoreFiles)
            {
                sb.Append("  ").Append(path).Append('\n');
            }
        }
    }

    private static string RenderJson(ChangedResult r)
    {
        var doc = new ChangedDocument
        {
            SchemaVersion = RepoContextInfo.SchemaVersion,
            Command = "changed",
            State = r.State,
            ContentState = r.ContentState,
            WorktreeState = r.WorktreeState,
            Stale = r.Stale,
            Count = r.Changed.Count,
            Changed = r.Changed.Select(c => new ChangedFileDto
            {
                Path = c.Path,
                Status = c.Status,
                PatchTokens = c.PatchTokens,
                FileTokens = c.FileTokens,
                Hunks = c.Hunks?.Select(h => new HunkDto
                {
                    OldStart = h.OldStart,
                    OldLines = h.OldLines,
                    NewStart = h.NewStart,
                    NewLines = h.NewLines,
                    Text = h.Text,
                }).ToList(),
            }).ToList(),
            Impacted = r.Impacted.Select(i => new ImpactedFileDto { Path = i.Path, Reasons = i.Reasons }).ToList(),
            Unreadable = r.Unreadable.Count == 0 ? null : r.Unreadable,
            UnreadableIgnoreFiles =
                r.UnreadableIgnoreFiles.Count == 0 ? null : r.UnreadableIgnoreFiles,
        };

        return JsonSerializer.Serialize(doc, OutputJson.Options);
    }

    private sealed record ChangedDocument
    {
        public int SchemaVersion { get; init; }

        public required string Command { get; init; }

        /// <summary>Short state hash of the index the tree was compared against.</summary>
        public required string State { get; init; }

        /// <summary>Short fingerprint of the indexed base contents.</summary>
        public required string ContentState { get; init; }

        /// <summary>Short fingerprint of the indexed base plus the local delta.</summary>
        public required string WorktreeState { get; init; }

        /// <summary>True when the working tree differs from the index.</summary>
        public bool Stale { get; init; }

        public int Count { get; init; }

        public required IReadOnlyList<ChangedFileDto> Changed { get; init; }

        public required IReadOnlyList<ImpactedFileDto> Impacted { get; init; }

        /// <summary>Files that could not be read, so nothing was checked about them.</summary>
        public IReadOnlyList<string>? Unreadable { get; init; }

        /// <summary>Ignore files whose rules could not be read, so their exclusions did not apply.</summary>
        public IReadOnlyList<string>? UnreadableIgnoreFiles { get; init; }
    }

    private sealed record ChangedFileDto
    {
        public required string Path { get; init; }

        public required string Status { get; init; }

        /// <summary>Cost of receiving the hunks (patch mode, modified files).</summary>
        public int? PatchTokens { get; init; }

        /// <summary>The full re-read the patch replaces (patch mode).</summary>
        public int? FileTokens { get; init; }

        /// <summary>Delta hunks vs the indexed content (patch mode).</summary>
        public IReadOnlyList<HunkDto>? Hunks { get; init; }
    }

    private sealed record HunkDto
    {
        public int OldStart { get; init; }

        public int OldLines { get; init; }

        public int NewStart { get; init; }

        public int NewLines { get; init; }

        /// <summary>Body lines prefixed ' ' (context), '-' (removed), '+' (added).</summary>
        public required string Text { get; init; }
    }

    private sealed record ImpactedFileDto
    {
        public required string Path { get; init; }

        public required IReadOnlyList<string> Reasons { get; init; }
    }
}
